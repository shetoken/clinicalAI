"""Extract features for all sample notes in parallel and write JSON outputs."""

from __future__ import annotations

import json
from pathlib import Path

from hh_note_features import extract_batch

ROOT = Path(__file__).resolve().parents[1]
NOTES_DIR = ROOT / "data" / "sample_notes"
OUT_DIR = ROOT / "data" / "extractions"


def main() -> None:
    note_paths = sorted(NOTES_DIR.glob("*.txt"))
    if not note_paths:
        raise SystemExit(f"No notes found in {NOTES_DIR}")

    notes = [(p.stem, p.read_text(encoding="utf-8")) for p in note_paths]
    print(f"Submitting {len(notes)} notes for extraction...")

    results = extract_batch(notes, concurrency=4)

    OUT_DIR.mkdir(parents=True, exist_ok=True)
    print(f"{'note':<45} {'status':<12} {'cluster':<8} {'dyspnea':<22} escalations")
    print("-" * 110)
    for path, res in zip(note_paths, results):
        if isinstance(res, Exception):
            print(f"{path.stem:<45} ERROR        — {res}")
            continue
        f = res.features
        (OUT_DIR / f"{path.stem}.json").write_text(
            json.dumps(f.model_dump(mode="json"), indent=2), encoding="utf-8"
        )
        print(
            f"{path.stem:<45} "
            f"{f.clinical_impression.overall_status.value:<12} "
            f"{f.clinical_impression.primary_diagnosis_cluster.value:<8} "
            f"{f.cardiopulmonary.dyspnea.value:<22} "
            f"{len(f.clinical_impression.escalation_indicators)}"
        )
    print(f"\nWrote JSON outputs to {OUT_DIR}")


if __name__ == "__main__":
    main()
