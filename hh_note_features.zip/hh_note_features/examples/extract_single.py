"""Extract features from a single visit note and print the result."""

from __future__ import annotations

import json
import sys
from pathlib import Path

from hh_note_features import extract_features

ROOT = Path(__file__).resolve().parents[1]
DEFAULT_NOTE = ROOT / "data" / "sample_notes" / "note_01_hfref_decompensation.txt"


def main() -> None:
    note_path = Path(sys.argv[1]) if len(sys.argv) > 1 else DEFAULT_NOTE
    note_text = note_path.read_text(encoding="utf-8")

    print(f"Extracting features from: {note_path.name}\n")
    result = extract_features(note_text, note_id=note_path.stem)

    feats = result.features
    print(f"Model: {result.model}")
    print(f"Usage: {result.usage}\n")
    print(f"Primary dx cluster : {feats.clinical_impression.primary_diagnosis_cluster.value}")
    print(f"Overall status     : {feats.clinical_impression.overall_status.value}")
    print(f"Dyspnea            : {feats.cardiopulmonary.dyspnea.value}")
    print(f"Weight delta (lbs) : {feats.vitals.weight_change_lbs}")
    print(f"BP                 : {feats.vitals.bp_systolic_mmhg}/{feats.vitals.bp_diastolic_mmhg}")
    print(f"SpO2 (RA={feats.vitals.spo2_on_room_air}) : {feats.vitals.spo2_percent}%")
    print()
    print("Escalation indicators:")
    for ind in feats.clinical_impression.escalation_indicators:
        print(f"  - {ind}")
    print()
    print("Flat signals (first 8):")
    for s in feats.flat_signals[:8]:
        ev = (s.evidence_quote or "").strip().replace("\n", " ")
        ev = ev[:80] + ("..." if len(ev) > 80 else "")
        print(f"  - {s.name} = {s.value}   [{s.confidence.value}]  evidence: {ev!r}")
    print()
    print("Potential documentation gaps:")
    for g in feats.doc_completeness.potential_documentation_gaps:
        print(f"  - {g}")
    print()
    print("---- full JSON ----")
    print(json.dumps(feats.model_dump(mode="json"), indent=2))


if __name__ == "__main__":
    main()
