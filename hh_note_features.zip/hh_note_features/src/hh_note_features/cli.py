"""CLI: extract features from a note file or a directory of notes.

Examples:
    hh-extract data/sample_notes/note_01_hfref_decompensation.txt
    hh-extract data/sample_notes/ --out out/ --model gemini-2.5-pro
    python -m hh_note_features.cli data/sample_notes/note_02_copd_routine.txt
"""

from __future__ import annotations

import argparse
import json
import logging
import sys
from pathlib import Path

from .extractor import DEFAULT_MODEL, extract_batch, extract_features


def _setup_logging(verbose: bool) -> None:
    logging.basicConfig(
        level=logging.DEBUG if verbose else logging.INFO,
        format="%(asctime)s %(levelname)s %(name)s | %(message)s",
    )


def _run_single(note_path: Path, out_path: Path | None, model: str) -> None:
    text = note_path.read_text(encoding="utf-8")
    result = extract_features(text, model=model, note_id=note_path.stem)
    payload = {
        "note_id": result.note_id,
        "model": result.model,
        "usage": result.usage,
        "features": result.features.model_dump(mode="json"),
    }
    out_text = json.dumps(payload, indent=2)
    if out_path:
        out_path.parent.mkdir(parents=True, exist_ok=True)
        out_path.write_text(out_text, encoding="utf-8")
        print(f"Wrote {out_path}")
    else:
        print(out_text)


def _run_directory(in_dir: Path, out_dir: Path, model: str, concurrency: int) -> None:
    note_paths = sorted(p for p in in_dir.iterdir() if p.suffix.lower() in {".txt", ".md"})
    if not note_paths:
        print(f"No .txt/.md notes found in {in_dir}", file=sys.stderr)
        sys.exit(1)

    notes = [(p.stem, p.read_text(encoding="utf-8")) for p in note_paths]
    results = extract_batch(notes, model=model, concurrency=concurrency)

    out_dir.mkdir(parents=True, exist_ok=True)
    failed = 0
    for path, result in zip(note_paths, results):
        target = out_dir / f"{path.stem}.json"
        if isinstance(result, Exception):
            failed += 1
            target.write_text(json.dumps({"error": str(result)}, indent=2), encoding="utf-8")
            print(f"FAILED {path.name}: {result}", file=sys.stderr)
            continue
        target.write_text(json.dumps({
            "note_id": result.note_id,
            "model": result.model,
            "usage": result.usage,
            "features": result.features.model_dump(mode="json"),
        }, indent=2), encoding="utf-8")
        print(f"OK     {path.name}  ->  {target}")
    if failed:
        sys.exit(1)


def main(argv: list[str] | None = None) -> None:
    parser = argparse.ArgumentParser(prog="hh-extract", description=__doc__)
    parser.add_argument("path", type=Path, help="Path to a note .txt file OR a directory of .txt files.")
    parser.add_argument("--out", type=Path, default=None,
                        help="Output JSON path (file) or directory (when path is a directory).")
    parser.add_argument("--model", default=DEFAULT_MODEL, help=f"Gemini model id (default: {DEFAULT_MODEL}).")
    parser.add_argument("--concurrency", type=int, default=4, help="Batch mode concurrency.")
    parser.add_argument("-v", "--verbose", action="store_true")
    args = parser.parse_args(argv)

    _setup_logging(args.verbose)

    if not args.path.exists():
        parser.error(f"path not found: {args.path}")

    if args.path.is_dir():
        out_dir = args.out or (args.path.parent / "extractions")
        _run_directory(args.path, out_dir, model=args.model, concurrency=args.concurrency)
    else:
        _run_single(args.path, args.out, model=args.model)


if __name__ == "__main__":
    main()
