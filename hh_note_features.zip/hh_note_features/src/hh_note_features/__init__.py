"""Home Health visit-note feature extraction via Gemini structured output."""

from .extractor import (
    DEFAULT_MODEL,
    ExtractionResult,
    extract_batch,
    extract_batch_async,
    extract_features,
)
from .schema import (
    Cardiopulmonary,
    CareContext,
    ClinicalImpression,
    DocCompleteness,
    FunctionSafety,
    Medications,
    Neurocognitive,
    Signal,
    Vitals,
    VisitNoteFeatures,
    Wound,
)

__all__ = [
    "DEFAULT_MODEL",
    "ExtractionResult",
    "extract_features",
    "extract_batch",
    "extract_batch_async",
    "VisitNoteFeatures",
    "Vitals",
    "Cardiopulmonary",
    "Neurocognitive",
    "Medications",
    "FunctionSafety",
    "Wound",
    "CareContext",
    "ClinicalImpression",
    "DocCompleteness",
    "Signal",
]

__version__ = "0.1.0"
