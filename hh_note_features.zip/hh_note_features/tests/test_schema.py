"""Schema-only smoke tests. Run without API access:

    pytest tests/
"""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from hh_note_features.schema import (
    DyspneaLevel,
    OverallStatus,
    Signal,
    VisitNoteFeatures,
)


def _minimal_payload() -> dict:
    return {
        "visit_type": "followup",
        "vitals": {},
        "cardiopulmonary": {"dyspnea": "not_documented"},
        "neurocognitive": {},
        "medications": {},
        "function_safety": {},
        "wound": {},
        "care_context": {},
        "clinical_impression": {
            "primary_diagnosis_cluster": "unclear",
            "overall_status": "stable",
            "rationale": "minimal test payload",
        },
        "doc_completeness": {},
    }


def test_minimal_payload_validates() -> None:
    feats = VisitNoteFeatures.model_validate(_minimal_payload())
    assert feats.cardiopulmonary.dyspnea is DyspneaLevel.NOT_DOCUMENTED
    assert feats.clinical_impression.overall_status is OverallStatus.STABLE
    assert feats.flat_signals == []


def test_flat_signal_round_trip() -> None:
    sig = Signal(name="dyspnea", value="on_exertion", evidence_quote="SOB with ambulation")
    parsed = Signal.model_validate(sig.model_dump())
    assert parsed.confidence.value == "medium"
    assert parsed.evidence_quote == "SOB with ambulation"


def test_rejects_invalid_enum() -> None:
    bad = _minimal_payload()
    bad["clinical_impression"]["overall_status"] = "flying"
    with pytest.raises(Exception):
        VisitNoteFeatures.model_validate(bad)


def test_sample_notes_exist_and_nonempty() -> None:
    notes_dir = Path(__file__).resolve().parents[1] / "data" / "sample_notes"
    notes = sorted(notes_dir.glob("*.txt"))
    assert len(notes) >= 5, "expected at least 5 sample notes"
    for n in notes:
        text = n.read_text(encoding="utf-8")
        assert len(text) > 200, f"sample note {n.name} seems too short"
        assert "SYNTHETIC" in text.upper(), f"{n.name} must be clearly labelled synthetic"


def test_json_schema_export_is_valid() -> None:
    schema = VisitNoteFeatures.model_json_schema()
    # round-trip the schema via JSON to make sure it's serializable.
    json.dumps(schema)
    assert "properties" in schema
    assert "cardiopulmonary" in schema["properties"]
